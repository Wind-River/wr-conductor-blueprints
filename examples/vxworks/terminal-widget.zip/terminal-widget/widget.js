(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
    "use strict";

    Stage.defineWidget({
        id: "terminalWidget",
        name: "Terminal widget",
        description: 'Displays VxWorks web terminal from deployment web_terminal_endpoint output',
        initialWidth: 2,
        initialHeight: 8,
        color: "blue",
        showHeader: false,
        isReact: true,
        permission: 'widget_custom_all',
        categories: [Stage.GenericConfig.CATEGORY.DEPLOYMENTS, Stage.GenericConfig.CATEGORY.CHARTS_AND_STATISTICS],

        initialConfiguration: [
            Stage.GenericConfig.POLLING_TIME_CONFIG(0)
        ],

        fetchData: function fetchData(widget, toolbox) {
            var deploymentId = toolbox.getContext().getValue('deploymentId');
            if (!deploymentId) return Promise.resolve({});
            return toolbox.getManager().doGet('/deployments/' + deploymentId + '/outputs');
        },

        render: function render(widget, data, error, toolbox) {
            var deploymentId = toolbox.getContext().getValue('deploymentId');
            if (!deploymentId) {
                return React.createElement("div", {
                    style: { padding: "20px", textAlign: "center", fontSize: "16px", color: "#666" }
                }, "No deployment selected.");
            }

            var pageUrl = '';
            if (data && data.outputs && data.outputs.web_terminal_endpoint) {
                pageUrl = data.outputs.web_terminal_endpoint;
            }

            if (!pageUrl) {
                return React.createElement("div", {
                    style: { padding: "20px", textAlign: "center", fontSize: "16px", color: "#666" }
                }, "No terminal endpoint available. Check deployment outputs.");
            }

            return React.createElement("div", {
                style: { position: "relative", width: "100%", height: "100%", minHeight: "400px", overflow: "hidden" }
            }, React.createElement("iframe", {
                src: pageUrl,
                frameBorder: "0",
                style: { position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: "none" }
            }));
        }
    });

},{}]},{},[1])
